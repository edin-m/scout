#define CUTE_PATH_IMPLEMENTATION
#include "cute_path.h"

int main(void)
{
	path_do_unit_tests();

	return 0;
}
