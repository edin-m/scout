#include <nlohmann/json.hpp>

int main(int argc, char **argv)
{
    nlohmann::json j;

    return 0;
}
